package codechicken.nei;

public class Image
{
    public int x;
    public int y;
    public int width;
    public int height;

    public Image(int i, int j, int k, int l)
    {
        x = i;
        y = j;
        width = k;
        height = l;
    }
}
