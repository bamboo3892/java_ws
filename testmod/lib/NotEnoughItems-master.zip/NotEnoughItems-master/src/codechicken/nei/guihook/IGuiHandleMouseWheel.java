package codechicken.nei.guihook;

/**
 * Interface for GuiContainers to recieve NEI compatible mouse wheel events
 */
public interface IGuiHandleMouseWheel
{
    public void mouseScrolled(int i);
}
