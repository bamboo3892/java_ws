package codechicken.nei;

public abstract class SlotOP
{
    public abstract String getDescription();
    
    public abstract int[] getKeyBind();
    
    public abstract void operate();
}
