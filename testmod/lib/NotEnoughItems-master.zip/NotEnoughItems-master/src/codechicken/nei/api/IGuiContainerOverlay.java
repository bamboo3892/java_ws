package codechicken.nei.api;

import net.minecraft.client.gui.inventory.GuiContainer;

public interface IGuiContainerOverlay
{
    public GuiContainer getFirstScreen();
}
